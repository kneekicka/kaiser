<?php

do_action('mprm_before_menu_item_single');

do_action('mprm_menu_item_single_theme_view');

do_action('mprm_after_menu_item_single');