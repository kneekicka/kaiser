<?php echo mprm_get_item_image();
