<?php
// {email} is replaced by the content entered in Menu items > Settings > Emails
?>
{email}
