<?php if (!empty($image)): ?>
	<div class="mprm-side mprm-left-side">
		<?php echo $image ?>
	</div>
<?php endif; ?>