<div id="setting-error-mprm-customer-deleted" class="updated settings-error notice is-dismissible">
	<p><strong><?php _e('Customer successfully deleted.', 'mp-restaurant-menu') ?></strong></p>
	<button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php _e('Dismiss this notice.', 'mp-restaurant-menu') ?></span></button>
</div>