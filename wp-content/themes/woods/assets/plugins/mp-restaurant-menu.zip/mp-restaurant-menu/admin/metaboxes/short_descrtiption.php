<?php
$args = array(
	'tinymce' => false,
	'quicktags' => false,
	'media_buttons' => false,
);
wp_editor($value, $name, $args);
